//
// AutoDetectEncoding.java
//
import java.io.*;
import oracle.xml.parser.v2.*;

public class AutoDetectEncoding
{
   public static void main(String[] args) throws Exception
   {
      // create an instance of the xml file, for example, myfile.xml
      File file = new File(args[0]);
      // create a binary input stream
      FileInputStream fis = new FileInputStream(file);
      // buffering for efficiency
      BufferedInputStream in = new BufferedInputStream(fis);
      // get an instance of the parser
      DOMParser parser = new DOMParser();
      // parse the xml file
      parser.parse(in);
      // get the document
      XMLDocument doc = parser.getDocument();
      System.out.println("Encoding is " + doc.getEncoding());
   }
}

